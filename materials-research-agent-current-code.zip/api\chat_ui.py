from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from agent.deepseek_intent_router import DeepSeekIntentRouter
from api.chat import resolve_user_context
from app.container import ApplicationContainer, get_container
from schemas.user_context import UserContext

router = APIRouter(prefix="/api/v1", tags=["chat-ui"])


class HistoryMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=8000)


class ChatUIRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    history: list[HistoryMessage] = Field(default_factory=list, max_length=20)
    attachment_ids: list[str] = Field(default_factory=list, max_length=8)


class ChatUIResponse(BaseModel):
    answer: str
    intent: str
    tool_name: str | None = None
    tool_args: dict[str, Any] = Field(default_factory=dict)
    data: Any = None
    evidence: list[dict[str, Any]] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    router: str = "deepseek"
    reasoning_summary: str = ""


@router.post("/chat-ui", response_model=ChatUIResponse)
def chat_ui(
    body: ChatUIRequest,
    ctx: UserContext = Depends(resolve_user_context),
    container: ApplicationContainer = Depends(get_container),
):
    if not container.settings.llm_enabled:
        raise HTTPException(503, "请先在后端 .env 启用并配置 DeepSeek：LLM_ENABLED=true")

    attachment_meta = []
    for attachment_id in body.attachment_ids:
        try:
            item = container.chat_attachment_store.get(attachment_id, ctx)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        attachment_meta.append(
            {
                "attachment_id": item.attachment_id,
                "filename": item.filename,
                "parser": item.parser,
                "page_count": item.page_count,
            }
        )

    engine = DeepSeekIntentRouter(container.llm)
    history = [{"role": x.role, "content": x.content} for x in body.history[-12:]]

    try:
        decision = engine.route(body.message, history, attachment_meta)
        router_name = "deepseek"
        summary = decision.reasoning_summary
        intent, tool_name, tool_args = decision.intent, decision.tool_name, decision.tool_args
    except Exception as exc:
        # V0.1.1 database questions retain the already validated rule fallback.
        fallback = container.core.rule_router.route(body.message)
        if fallback is None:
            if body.attachment_ids:
                # Safe current-attachment fallback: it still cannot access MySQL directly.
                intent, tool_name, tool_args = "ask_current_attachment", None, {}
                router_name = "attachment_fallback"
                summary = "DeepSeek 路由失败，按当前 Chat 附件问题处理。"
            else:
                raise HTTPException(400, f"DeepSeek 意图识别失败：{type(exc).__name__}: {exc}") from exc
        else:
            intent, tool_name, tool_args = fallback.intent, fallback.tool_name, fallback.tool_args
            router_name = "rule_fallback"
            summary = "DeepSeek 路由失败，使用 V0.1.1 规则路由兜底。"

    if intent in {"analyze_current_attachment", "ask_current_attachment"}:
        if not body.attachment_ids:
            raise HTTPException(status_code=400, detail="请先上传 PDF 或 DOCX 附件")
        try:
            result = container.current_attachment_skill.answer(
                message=body.message,
                attachment_ids=body.attachment_ids,
                ctx=ctx,
            )
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=str(exc)) from exc
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail=f"当前附件分析失败：{type(exc).__name__}: {exc}",
            ) from exc
        return ChatUIResponse(
            answer=result.get("answer", ""),
            intent=intent,
            tool_name=None,
            tool_args={},
            data=result,
            evidence=result.get("evidence", []),
            warnings=result.get("warnings", []),
            router=router_name,
            reasoning_summary=summary,
        )

    if intent == "unsupported_future_feature":
        return ChatUIResponse(
            answer=(
                "当前 V0.1.2-A 已开放 Chat 临时 PDF/DOCX 上传与当前附件分析；"
                "长期 Knowledge Index、Qdrant 和历史 RAG 会在本版本下一阶段接入。"
            ),
            intent=intent,
            tool_name=None,
            tool_args=tool_args,
            data={"available_version": "V0.1.2-A"},
            router=router_name,
            reasoning_summary=summary,
        )

    if tool_name is None:
        raise HTTPException(400, "已识别意图，但没有可执行 Tool")

    try:
        result = container.core.execute(intent, tool_name, tool_args, ctx)
        answer = container.core.answer(body.message, intent, result)
    except Exception as exc:
        raise HTTPException(500, f"Agent 执行失败：{type(exc).__name__}: {exc}") from exc

    evidence = result.get("evidence", []) if isinstance(result, dict) else []
    warnings = result.get("warnings", []) if isinstance(result, dict) else []
    return ChatUIResponse(
        answer=answer,
        intent=intent,
        tool_name=tool_name,
        tool_args=tool_args,
        data=result,
        evidence=evidence,
        warnings=warnings,
        router=router_name,
        reasoning_summary=summary,
    )
