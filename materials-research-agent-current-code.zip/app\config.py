from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "materials-research-agent"
    app_env: str = "development"
    log_level: str = "INFO"

    business_db_host: str = "127.0.0.1"
    business_db_port: int = 3306
    business_db_user: str = ""
    business_db_password: SecretStr = SecretStr("")
    business_db_name: str = "materials"
    business_db_charset: str = "utf8mb4"
    business_db_connect_timeout: int = 10
    business_db_read_timeout: int = 30

    permission_mode: Literal["development_header", "platform"] = "development_header"

    llm_enabled: bool = False
    llm_base_url: str = ""
    llm_api_key: SecretStr = SecretStr("")
    llm_model: str = ""
    llm_timeout: int = 60

    # V0.1.2-A: current Chat temporary attachments
    chat_upload_dir: str = ".runtime/chat_uploads"
    chat_upload_max_mb: int = 25
    chat_upload_ttl_minutes: int = 180

    runtime_enabled: bool = False

    runtime_db_host: str = ""
    runtime_db_port: int = 3306
    runtime_db_user: str = ""
    runtime_db_password: SecretStr = SecretStr("")
    runtime_db_name: str = "materials_agent_runtime"
    runtime_db_charset: str = "utf8mb4"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    @model_validator(mode="after")
    def validate_runtime_is_separate(self) -> "Settings":
        if self.runtime_enabled:
            if not self.runtime_db_name.strip():
                raise ValueError("RUNTIME_DB_NAME 不能为空")
            if self.runtime_db_name.strip().lower() == self.business_db_name.strip().lower():
                raise ValueError(
                    "Agent Runtime 必须使用独立数据库；RUNTIME_DB_NAME 不能等于 BUSINESS_DB_NAME"
                )
        return self

    def require_business_db(self) -> None:
        missing = []
        if not self.business_db_host.strip():
            missing.append("BUSINESS_DB_HOST")
        if not self.business_db_user.strip():
            missing.append("BUSINESS_DB_USER")
        if not self.business_db_password.get_secret_value():
            missing.append("BUSINESS_DB_PASSWORD")
        if not self.business_db_name.strip():
            missing.append("BUSINESS_DB_NAME")
        if missing:
            raise RuntimeError("缺少业务数据库配置：" + ", ".join(missing))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
