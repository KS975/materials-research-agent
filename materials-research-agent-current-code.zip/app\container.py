from __future__ import annotations

from functools import lru_cache

from agent.core import AgentCore
from agent.service import MaterialsAgentService
from agent.tool_registry import ToolRegistry
from agent.tools import MaterialsTools
from app.config import Settings, get_settings
from data.dynamic_fields import DynamicFieldResolver
from data.mysql.client import BusinessMySQLClient
from data.mysql.repositories import (
    ArchiveRepository,
    ColumnDefinitionRepository,
    ExperimentRepository,
    MaterialRepository,
    ProjectRepository,
    SampleRepository,
)
from llm.factory import create_llm_provider
from file_processing import ChatFileParser
from runtime.chat_attachments import ChatAttachmentStore
from skills.current_attachment import CurrentAttachmentSkill
from runtime.store import create_runtime_store


class ApplicationContainer:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.db = BusinessMySQLClient(settings)

        self.samples = SampleRepository(self.db)
        self.projects = ProjectRepository(self.db)
        self.materials = MaterialRepository(self.db)
        self.columns = ColumnDefinitionRepository(self.db)
        self.archives = ArchiveRepository(self.db)
        self.experiments = ExperimentRepository(self.db)

        self.resolver = DynamicFieldResolver(self.materials, self.columns)
        self.tools = MaterialsTools(
            samples=self.samples,
            projects=self.projects,
            archives=self.archives,
            experiments=self.experiments,
            resolver=self.resolver,
        )

        self.registry = ToolRegistry()
        self.registry.register(
            "get_sample_context",
            "读取样品完整研发上下文：项目、配方、工艺、性能、测试条件和可选实验记录",
            self.tools.get_sample_context,
        )
        self.registry.register("get_formula", "读取样品配方", self.tools.get_formula)
        self.registry.register("get_process", "读取样品工艺", self.tools.get_process)
        self.registry.register("get_performance", "读取样品性能及测试条件", self.tools.get_performance)
        self.registry.register("compare_samples", "比较两个样品的配方、工艺、性能和测试条件", self.tools.compare_samples)
        self.registry.register("find_samples", "在当前公司/项目权限范围内查找样品", self.tools.find_samples)

        self.llm = create_llm_provider(settings)
        # V0.1.2-A: Current Chat temporary attachments
        self.chat_file_parser = ChatFileParser()

        self.chat_attachment_store = ChatAttachmentStore(
            settings.chat_upload_dir,
            settings.chat_upload_ttl_minutes,
        )

        self.current_attachment_skill = CurrentAttachmentSkill(
            self.chat_attachment_store,
            self.llm,
        )
        self.core = AgentCore(
            registry=self.registry,
            llm=self.llm,
            llm_enabled=settings.llm_enabled,
        )
        self.runtime = create_runtime_store(settings)
        self.agent = MaterialsAgentService(self.core, self.runtime)


@lru_cache(maxsize=1)
def get_container() -> ApplicationContainer:
    return ApplicationContainer(get_settings())
